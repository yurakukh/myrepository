﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab_11_kukharenko
{
   public class Product
    {
        public bool SizesTaken { get; set; }
        public bool CutOff { get; set; }
        public bool Sharpened { get; set; }
        public bool Thread { get; set; }
        public bool Drilled { get; set; }
        public bool Painted { get; set; }
        public bool Tested { get; set; }
        public bool Packed { get; set; }


    }
}
